import socket

SERVER_IP = '127.0.0.1'
PORT = 5000

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect((SERVER_IP, PORT))

while True:
    message = input("Client: ")

    client.send(message.encode())

    data = client.recv(1024)

    print("Server:", data.decode())